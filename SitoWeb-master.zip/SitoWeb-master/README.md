# SitoWeb
E' il mio primo sito web, è fatto appositamente in GET per il controllo dei parametri, alcune servlet possono essere riscritte creandone una sola, spero vi sia utile.
P.S. E' la mia prima webapp in java, grazie per l'attenzione.
