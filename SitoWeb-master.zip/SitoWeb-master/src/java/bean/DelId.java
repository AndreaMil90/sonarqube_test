package bean;
public class DelId {

    private final int id;
   
    
    public DelId(int id){
        this.id = id;
        
    }
    public int getId() {
		return id;
	}
    public int setId() {
		return id;
	}
}
